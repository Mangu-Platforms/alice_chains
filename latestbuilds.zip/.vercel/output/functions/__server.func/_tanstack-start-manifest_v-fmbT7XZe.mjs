//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-fmbT7XZe.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/product",
			"/spec/$section",
			"/spec/"
		],
		preloads: ["/assets/index-DeqP6L1X.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DeqP6L1X.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CQ8ZW0T2.js", "/assets/mark-CRjPALvC.js"]
	},
	"/product": {
		filePath: "/workspace/src/routes/product.tsx",
		children: void 0,
		preloads: ["/assets/product-DJ7LAi8J.js"]
	},
	"/spec/$section": {
		filePath: "/workspace/src/routes/spec.$section.tsx",
		children: void 0,
		preloads: ["/assets/spec._section-BK95v5ts.js", "/assets/mark-CRjPALvC.js"]
	}
} });
//#endregion
export { tsrStartManifest };
