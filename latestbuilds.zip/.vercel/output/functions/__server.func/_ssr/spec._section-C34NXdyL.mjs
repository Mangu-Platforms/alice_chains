import { b as require_jsx_runtime, d as useRouterState, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route, r as SECTIONS } from "./router-DQROmTni.mjs";
import { n as cn, t as Mark } from "./mark-BSEiXSy5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/spec._section-C34NXdyL.js
var import_jsx_runtime = require_jsx_runtime();
function Shell({ children }) {
	const spec = useRouterState({ select: (s) => s.location.pathname }).startsWith("/spec");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur-sm",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex h-14 max-w-6xl items-center justify-between px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-2 text-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium tracking-widest",
						children: "ALISONS"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "rounded-full px-3 py-1.5 text-sm text-muted hover:text-foreground",
						children: "Room"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/spec/$section",
						params: { section: "features" },
						className: cn("rounded-full px-3 py-1.5 text-sm", spec ? "bg-primary text-primary-foreground" : "text-muted hover:text-foreground"),
						children: "Spec"
					})]
				})]
			})
		}), children]
	});
}
var STATUS_LABEL = {
	shipped: "In the repo",
	stub: "Button only",
	hygiene: "Open hygiene",
	specified: "Specified, unbuilt",
	parked: "Parked track",
	missing: "Not yet specified"
};
var STATUS_TONE = {
	shipped: "text-ok",
	stub: "text-warn",
	hygiene: "text-warn",
	specified: "text-accent",
	parked: "text-muted",
	missing: "text-bad"
};
function StatusChip({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium tracking-wide", "bg-raised text-muted", STATUS_TONE[status]),
		children: STATUS_LABEL[status]
	});
}
var FEATURES = [
	{
		id: "F-MSG",
		name: "Real-time text messaging",
		layer: "core",
		status: "shipped",
		story: "As a member I send a message and every other participant sees it without refreshing.",
		note: "Socket.IO rooms + tRPC persist. Sub-100ms is claimed, unmeasured."
	},
	{
		id: "F-DM",
		name: "Direct conversations",
		layer: "core",
		status: "shipped",
		story: "As a member I open a private 1:1 with an accepted contact.",
		note: "Idempotent createDirect after Wave 1."
	},
	{
		id: "F-GRP",
		name: "Group conversations",
		layer: "core",
		status: "shipped",
		story: "As a member I create a named group, add people, leave, transfer ownership.",
		note: "F-7 group management is in the repo."
	},
	{
		id: "F-CTC",
		name: "Contacts and requests",
		layer: "core",
		status: "shipped",
		story: "As a member I search, request, accept, decline, and remove contacts.",
		note: "Three-state machine: pending / accepted / blocked."
	},
	{
		id: "F-BLK",
		name: "Blocking",
		layer: "core",
		status: "shipped",
		story: "As a member I block someone and they cannot message, add, or see my presence.",
		note: "One shared isBlockedBetween predicate on every path."
	},
	{
		id: "F-PRE",
		name: "Presence",
		layer: "core",
		status: "shipped",
		story: "As a member I see who is online across tabs and devices.",
		note: "In-process Map. Does not survive multi-instance."
	},
	{
		id: "F-TYP",
		name: "Typing indicators",
		layer: "core",
		status: "shipped",
		story: "As a member I see when the other person is composing.",
		note: "Socket event, conversation-scoped."
	},
	{
		id: "F-READ",
		name: "Read receipts",
		layer: "core",
		status: "shipped",
		story: "As a sender I know when a message was read.",
		note: "message_reads table; Wave 1 fixed the IN (?) bind bug."
	},
	{
		id: "F-UNR",
		name: "Unread badges",
		layer: "enrichment",
		status: "shipped",
		story: "As a member I see how many unread messages sit in each conversation.",
		note: "Computed from lastReadAt. Caps at 99+ in UI."
	},
	{
		id: "F-EDT",
		name: "Edit and soft-delete",
		layer: "enrichment",
		status: "shipped",
		story: "As an author I correct or retract a message without breaking the thread.",
		note: "isEdited + deletedAt. Realtime messageUpdated / messageDeleted."
	},
	{
		id: "F-RXN",
		name: "Emoji reactions",
		layer: "enrichment",
		status: "shipped",
		story: "As a member I react to a message with an emoji, once per emoji.",
		note: "Unique (message, user, emoji)."
	},
	{
		id: "F-ATT",
		name: "File and image attachments",
		layer: "enrichment",
		status: "shipped",
		story: "As a member I attach a photo or file and others can open it.",
		note: "Filesystem driver default; S3/MinIO behind STORAGE_DRIVER. 50MB cap."
	},
	{
		id: "F-RPL",
		name: "Reply threading",
		layer: "enrichment",
		status: "shipped",
		story: "As a member I reply to a specific message and jump back to it.",
		note: "replyToId. History older than 50 messages cannot be jumped to (H-9)."
	},
	{
		id: "F-PUSH",
		name: "Web push",
		layer: "enrichment",
		status: "shipped",
		story: "As a member I get an OS notification when the tab is closed.",
		note: "VAPID + service worker. iOS needs PWA install."
	},
	{
		id: "F-SRCH",
		name: "Message search",
		layer: "enrichment",
		status: "shipped",
		story: "As a member I search this conversation or everywhere I belong.",
		note: "MySQL FULLTEXT, not Meilisearch. PRD still names Meilisearch."
	},
	{
		id: "F-PROF",
		name: "Profile",
		layer: "enrichment",
		status: "shipped",
		story: "As a member I set name, status, avatar, and sign out every device.",
		note: "Settings page. Admin.revokeAllSessions."
	},
	{
		id: "F-OUT",
		name: "Offline outbox",
		layer: "enrichment",
		status: "shipped",
		story: "As a member I can compose while disconnected; send retries on restore.",
		note: "Connection banner + client outbox."
	},
	{
		id: "F-CMP",
		name: "Composer",
		layer: "enrichment",
		status: "shipped",
		story: "As a member I use shift+enter, paste-to-attach, emoji, and a length counter.",
		note: "4000-character cap enforced on socket and tRPC."
	},
	{
		id: "F-MED",
		name: "Media drawer",
		layer: "enrichment",
		status: "shipped",
		story: "As a member I browse every photo and file shared in this room.",
		note: "P-UX-4."
	},
	{
		id: "F-LNK",
		name: "Link detection",
		layer: "enrichment",
		status: "shipped",
		story: "As a member I tap a URL and it opens safely.",
		note: "rel=noopener. No unfurling."
	},
	{
		id: "F-AUTH",
		name: "Kimi OAuth + signed sessions",
		layer: "platform",
		status: "shipped",
		story: "As a member I sign in with the identity provider and stay signed in.",
		note: "PKCE S256, HMAC cookie, server-side session store. Not passkeys. Single IdP."
	},
	{
		id: "F-RL",
		name: "Rate limiting",
		layer: "platform",
		status: "shipped",
		story: "As an operator I am protected from spam and floods.",
		note: "S-13. Redis not required."
	},
	{
		id: "F-OBS",
		name: "Health and logs",
		layer: "platform",
		status: "shipped",
		story: "As an operator I probe /healthz and /readyz and read redacted logs.",
		note: "S-15. No full SLO dashboard."
	},
	{
		id: "F-ADM",
		name: "Admin data rights",
		layer: "platform",
		status: "shipped",
		story: "As the owner I list members, deactivate, export, and erase.",
		note: "API exists. No admin console page."
	},
	{
		id: "F-A11Y",
		name: "Accessibility baseline",
		layer: "platform",
		status: "shipped",
		story: "As a screen-reader user I can operate chat with a keyboard.",
		note: "S-20. Remaining display strings still inline (S-20a)."
	},
	{
		id: "F-CALL",
		name: "Voice and video calls",
		layer: "enterprise",
		status: "stub",
		story: "As a member I start a voice or video call from the header.",
		note: "Icons render. No signaling, no STUN/TURN, no media."
	},
	{
		id: "F-SHARE",
		name: "Screen sharing",
		layer: "enterprise",
		status: "specified",
		story: "As a member I share a window during a call.",
		note: "PRD Phase 3. Depends on WebRTC."
	},
	{
		id: "F-VOICE",
		name: "Voice notes",
		layer: "enterprise",
		status: "specified",
		story: "As a member I hold to record and send an audio bubble.",
		note: "PRD Phase 3. MediaRecorder + dual encoding."
	},
	{
		id: "F-REDIS",
		name: "Horizontal realtime scale",
		layer: "platform",
		status: "specified",
		story: "As an operator I run two nodes and presence stays consistent.",
		note: "S-19 gated on 6k connections. ADR-006 trigger."
	},
	{
		id: "F-MOB",
		name: "Native iOS and Android",
		layer: "enterprise",
		status: "specified",
		story: "As a member I use Alisons as a home-screen app with background push.",
		note: "PRD Phase 4. Not started. PWA is the current mobile story."
	},
	{
		id: "F-E2EE",
		name: "End-to-end encryption (MLS)",
		layer: "crypto",
		status: "parked",
		story: "As a member I know the server cannot read my messages.",
		note: "Track B. PRD said Signal Protocol; the serious plan is MLS. Not on the current stack."
	},
	{
		id: "F-DEV",
		name: "Device identity and revocation",
		layer: "crypto",
		status: "parked",
		story: "As a member I link a laptop, verify a phrase, and kill a stolen phone.",
		note: "Passkeys + device certificates. Track B Phase 2."
	},
	{
		id: "F-ALICE",
		name: "Visible AI participant",
		layer: "enterprise",
		status: "parked",
		story: "As a group I admit Alice into the room, see what she can read, and remove her.",
		note: "The differentiator. Never an invisible backend observer."
	},
	{
		id: "F-ARCH",
		name: "Encrypted recoverable history",
		layer: "crypto",
		status: "parked",
		story: "As a member I restore entitled history on a new device without giving the server plaintext.",
		note: "Track B Phase 7."
	},
	{
		id: "F-LSEARCH",
		name: "Local encrypted search",
		layer: "crypto",
		status: "parked",
		story: "As a member I search private content with no network request.",
		note: "Today search hits MySQL. That is the opposite of this."
	},
	{
		id: "F-SSO",
		name: "Enterprise SSO / SCIM",
		layer: "enterprise",
		status: "missing",
		story: "As an IT admin I provision seats from Okta and deprovision on offboarding.",
		note: "Explicitly excluded from MVP in the MLS program. Required for enterprise GA."
	},
	{
		id: "F-HOLD",
		name: "Legal hold, DLP, eDiscovery",
		layer: "enterprise",
		status: "missing",
		story: "As counsel I freeze a matter and export it under warrant.",
		note: "Conflicts with true E2EE. Needs MANAGED conversation mode."
	},
	{
		id: "F-AUDIT",
		name: "Immutable audit log UI",
		layer: "enterprise",
		status: "specified",
		story: "As a compliance officer I review auth, admin, and data-access events.",
		note: "API writes exist. No operator UI. 7-year archive unspecified in code."
	},
	{
		id: "F-FED",
		name: "Federation",
		layer: "enterprise",
		status: "missing",
		story: "As two organizations we talk without sharing a host.",
		note: "Excluded from MVP. Matrix-class problem."
	},
	{
		id: "F-PAGE",
		name: "History pagination",
		layer: "core",
		status: "hygiene",
		story: "As a member I scroll to messages older than the last 50.",
		note: "H-9. Server supports limit/offset; client never pages."
	}
];
FEATURES.reduce((acc, f) => {
	acc[f.status] += 1;
	return acc;
}, {
	shipped: 0,
	stub: 0,
	hygiene: 0,
	specified: 0,
	parked: 0,
	missing: 0
});
var SURFACES = [
	{
		name: "Login",
		path: "/login",
		kind: "page",
		status: "shipped",
		purpose: "Send the browser to Kimi OAuth. No password, no passkey, no email magic link.",
		build: "Login.tsx. Eager chunk. Redirects to provider authorize URL."
	},
	{
		name: "Chat",
		path: "/",
		kind: "page",
		status: "shipped",
		purpose: "The product. Conversation list + active thread + composer.",
		build: "Chat.tsx ~81k. God component. Must be split before Phase 3."
	},
	{
		name: "Conversation list",
		path: "/ · sidebar",
		kind: "subpage",
		parent: "Chat",
		status: "shipped",
		purpose: "Sorted by recency. Avatar, preview, time, unread pill, presence dot.",
		build: "320px sidebar. Overlay below 768px. Collapsed state persisted (P-PROF-2)."
	},
	{
		name: "Thread pane",
		path: "/ · thread",
		kind: "subpage",
		parent: "Chat",
		status: "shipped",
		purpose: "Bubbles, ticks, edits, deletes, replies, reactions, typing dots.",
		build: "Fixed most-recent 50. No infinite scroll (H-9)."
	},
	{
		name: "Composer",
		path: "/ · composer",
		kind: "tool",
		parent: "Chat",
		status: "shipped",
		purpose: "Auto-resize textarea, attach, emoji, send, character remaining.",
		build: "Shift+enter newline. Paste-to-attach. 4000 cap."
	},
	{
		name: "Chat header",
		path: "/ · header",
		kind: "tool",
		parent: "Chat",
		status: "shipped",
		purpose: "Name, presence, search, media, call, video, more.",
		build: "Call and video are stubs by design."
	},
	{
		name: "Account menu",
		path: "/ · account menu",
		kind: "menu",
		parent: "Chat",
		status: "shipped",
		purpose: "Open settings, contacts, sign out.",
		build: "Dropdown on avatar."
	},
	{
		name: "Conversation options",
		path: "/ · conversation menu",
		kind: "menu",
		parent: "Chat",
		status: "shipped",
		purpose: "Group rename, members, leave, ownership, block.",
		build: "F-7 + F-8."
	},
	{
		name: "Message actions",
		path: "/ · message menu",
		kind: "menu",
		parent: "Chat",
		status: "shipped",
		purpose: "Reply, edit, delete, react.",
		build: "Hover / long-press."
	},
	{
		name: "Emoji picker",
		path: "/ · emoji",
		kind: "overlay",
		parent: "Chat",
		status: "shipped",
		purpose: "Insert emoji into composer or as a reaction.",
		build: "EmojiPicker.tsx. Not a full Unicode set."
	},
	{
		name: "In-conversation search",
		path: "/ · search",
		kind: "overlay",
		parent: "Chat",
		status: "shipped",
		purpose: "Find messages in this room. Jump if loaded.",
		build: "P-SEARCH-1. Hits outside the 50-window show a notice."
	},
	{
		name: "Global search",
		path: "/ · search everywhere",
		kind: "overlay",
		parent: "Chat",
		status: "shipped",
		purpose: "Search every conversation the caller belongs to.",
		build: "P-SEARCH-2. Scoped. No directory leak."
	},
	{
		name: "Media drawer",
		path: "/ · media",
		kind: "drawer",
		parent: "Chat",
		status: "shipped",
		purpose: "Photos and files in this conversation, with download.",
		build: "MediaDrawer.tsx."
	},
	{
		name: "Connection banner",
		path: "/ · banner",
		kind: "banner",
		parent: "Chat",
		status: "shipped",
		purpose: "Tell the member the socket is down and that sends are queued.",
		build: "ConnectionBanner.tsx + outbox."
	},
	{
		name: "Group management dialog",
		path: "/ · group",
		kind: "dialog",
		parent: "Chat",
		status: "shipped",
		purpose: "Rename, avatar, add/remove members, leave, transfer owner.",
		build: "Inside Chat.tsx. Extract."
	},
	{
		name: "Attachment preview",
		path: "/ · preview",
		kind: "overlay",
		parent: "Chat",
		status: "shipped",
		purpose: "Open an image or download a file from a bubble.",
		build: "Type image/file on messages."
	},
	{
		name: "Contacts",
		path: "/contacts",
		kind: "page",
		status: "shipped",
		purpose: "The people graph.",
		build: "Contacts.tsx. Lazy chunk."
	},
	{
		name: "My Contacts",
		path: "/contacts?tab=contacts",
		kind: "tab",
		parent: "Contacts",
		status: "shipped",
		purpose: "Accepted people. Search, message, remove.",
		build: "TabsTrigger contacts."
	},
	{
		name: "Pending requests",
		path: "/contacts?tab=pending",
		kind: "tab",
		parent: "Contacts",
		status: "shipped",
		purpose: "Incoming requests. Accept or decline.",
		build: "contact.pending."
	},
	{
		name: "Add Contact",
		path: "/contacts · add",
		kind: "dialog",
		parent: "Contacts",
		status: "shipped",
		purpose: "Search directory by name or email and send a request.",
		build: "Minimum query length. Email no longer returned on 1-char match."
	},
	{
		name: "Settings",
		path: "/settings",
		kind: "page",
		status: "shipped",
		purpose: "Picture, display name, status, sign out everywhere.",
		build: "Settings.tsx. Four sections, one page. No nested routes."
	},
	{
		name: "Picture",
		path: "/settings#picture",
		kind: "subpage",
		parent: "Settings",
		status: "shipped",
		purpose: "Upload or remove avatar.",
		build: "Presigned PUT. JPEG/PNG/GIF/WebP."
	},
	{
		name: "Profile fields",
		path: "/settings#profile",
		kind: "subpage",
		parent: "Settings",
		status: "shipped",
		purpose: "Name and status line.",
		build: "user.updateProfile."
	},
	{
		name: "Security",
		path: "/settings#security",
		kind: "subpage",
		parent: "Settings",
		status: "shipped",
		purpose: "Revoke every session including this one.",
		build: "admin.revokeAllSessions — no device list, no passkeys."
	},
	{
		name: "Account",
		path: "/settings#account",
		kind: "subpage",
		parent: "Settings",
		status: "shipped",
		purpose: "Show signed-in email. No delete-account control.",
		build: "Read-only."
	},
	{
		name: "Not found",
		path: "*",
		kind: "page",
		status: "shipped",
		purpose: "Unknown routes.",
		build: "NotFound.tsx. Minimal."
	},
	{
		name: "Auth skeleton",
		path: "gated layout",
		kind: "overlay",
		status: "shipped",
		purpose: "Hold the layout while auth.me resolves.",
		build: "AuthLayoutSkeleton."
	},
	{
		name: "Voice call",
		path: "/ · call overlay",
		kind: "overlay",
		parent: "Chat",
		status: "stub",
		purpose: "Full-screen call with mute, speaker, end.",
		build: "Button only. No overlay, no WebRTC."
	},
	{
		name: "Video call",
		path: "/ · video overlay",
		kind: "overlay",
		parent: "Chat",
		status: "stub",
		purpose: "Grid of camera tiles plus screen share.",
		build: "Button only."
	},
	{
		name: "Admin console",
		path: "/admin",
		kind: "page",
		status: "missing",
		purpose: "Member list, deactivation, audit, export, erasure.",
		build: "admin-router.ts has procedures. Zero routes. This is a hole."
	},
	{
		name: "Onboarding",
		path: "/welcome",
		kind: "page",
		status: "missing",
		purpose: "First private conversation within ten minutes.",
		build: "Not in the repo. Track B activation metric."
	},
	{
		name: "Devices",
		path: "/settings/devices",
		kind: "page",
		status: "parked",
		purpose: "Linked devices, verification phrase, revoke.",
		build: "Track B Phase 2. Required before E2EE."
	},
	{
		name: "Security dashboard",
		path: "/settings/security",
		kind: "page",
		status: "parked",
		purpose: "Safety numbers, mode indicator, archive limits, Alice access.",
		build: "Track B Epic 5.2."
	},
	{
		name: "Alice admission",
		path: "/ · admit Alice",
		kind: "dialog",
		parent: "Chat",
		status: "parked",
		purpose: "Disclose provider, retention, capabilities. Require consent.",
		build: "The signature differentiator. Unbuilt."
	},
	{
		name: "Notification center",
		path: "/inbox",
		kind: "page",
		status: "missing",
		purpose: "Missed calls, device events, contact requests, system notices.",
		build: "Push exists; no in-app inbox of events."
	},
	{
		name: "Call history",
		path: "/calls",
		kind: "page",
		status: "specified",
		purpose: "Past voice and video sessions.",
		build: "Depends on WebRTC. No schema."
	},
	{
		name: "Workspace",
		path: "/org",
		kind: "page",
		status: "missing",
		purpose: "Tenant, SSO, retention policy, billing.",
		build: "Single-tenant self-host today. No org model."
	},
	{
		name: "Data export",
		path: "/settings/export",
		kind: "page",
		status: "specified",
		purpose: "Download my data. GDPR portability.",
		build: "Admin API can export. No member-facing flow."
	},
	{
		name: "Account deletion",
		path: "/settings/delete",
		kind: "dialog",
		parent: "Settings",
		status: "specified",
		purpose: "Right to erasure with cascading delete.",
		build: "PRD GDPR section. Not a button."
	},
	{
		name: "Invite landing",
		path: "/i/:code",
		kind: "page",
		status: "missing",
		purpose: "Join a group from a link without a prior account.",
		build: "No invite tokens."
	},
	{
		name: "Legal",
		path: "/legal",
		kind: "page",
		status: "missing",
		purpose: "Privacy, terms, AUP, DPA, subprocessors.",
		build: "MIT license only. No product legal."
	},
	{
		name: "Dev seed tool",
		path: "npm run db:seed",
		kind: "tool",
		status: "shipped",
		purpose: "Three demo members, a DM, a group, printed session cookies.",
		build: "scripts/seed.ts. Local databases only."
	},
	{
		name: "Dev bootstrap",
		path: "./scripts/dev.sh",
		kind: "tool",
		status: "shipped",
		purpose: "From clone to running app.",
		build: "P-TOOL-1."
	},
	{
		name: "Reset-dev",
		path: "scripts/reset-dev.sh",
		kind: "tool",
		status: "hygiene",
		purpose: "Destructive local reset, guarded.",
		build: "P-TOOL-2. Not started."
	},
	{
		name: "Drizzle Studio",
		path: "npm run db:studio",
		kind: "tool",
		status: "shipped",
		purpose: "Inspect tables.",
		build: "Operator only."
	},
	{
		name: "VAPID generator",
		path: "npm run generate-vapid",
		kind: "tool",
		status: "shipped",
		purpose: "Mint web-push keys.",
		build: "scripts/generate-vapid.mjs."
	}
];
var DOCUMENTS = [
	{
		order: 1,
		phase: "0 · Identity",
		name: "Product thesis (one sentence)",
		why: "Without this every later doc argues with itself.",
		have: "in-repo",
		source: "PRD vision + Track B §1.1"
	},
	{
		order: 2,
		phase: "0 · Identity",
		name: "Naming & trademark opinion — Alisons",
		why: "You cannot ship a rename on hope.",
		have: "missing"
	},
	{
		order: 3,
		phase: "0 · Identity",
		name: "Brand identity system",
		why: "Mark, type, color, voice. This preview is a draft of that.",
		have: "missing"
	},
	{
		order: 4,
		phase: "0 · Identity",
		name: "Competitive teardown",
		why: "Slack, Discord, Mattermost, Signal, WhatsApp. Already sketched.",
		have: "in-repo",
		source: "docs/PRD.md"
	},
	{
		order: 5,
		phase: "1 · Product",
		name: "PRD",
		why: "What it is, who it is for, what Phase 1–4 means.",
		have: "in-repo",
		source: "docs/PRD.md"
	},
	{
		order: 6,
		phase: "1 · Product",
		name: "SRS (164 requirements)",
		why: "The contract for what. Status must be re-baselined against Wave 4.",
		have: "stale",
		source: "docs/SRS.md"
	},
	{
		order: 7,
		phase: "1 · Product",
		name: "Jobs-to-be-done interview set",
		why: "Ten trusted-group interviews. The PRD is desk research.",
		have: "missing"
	},
	{
		order: 8,
		phase: "1 · Product",
		name: "Information architecture",
		why: "Every page, subpage, popup. This app is the first IA.",
		have: "missing"
	},
	{
		order: 9,
		phase: "1 · Product",
		name: "User stories & acceptance criteria",
		why: "Traceable to SRS ids. BUILD_PLAN has task cards; stories are thinner.",
		have: "in-repo",
		source: "docs/BUILD_PLAN.md"
	},
	{
		order: 10,
		phase: "1 · Product",
		name: "UX flows (sign-in, first room, call, Alice admit)",
		why: "Cannot build the iPhone from a Chat.tsx dump.",
		have: "missing"
	},
	{
		order: 11,
		phase: "1 · Product",
		name: "Design system spec",
		why: "Tokens, type, motion, components. PRD still specifies violet glassmorphism.",
		have: "stale",
		source: "docs/PRD.md §UI"
	},
	{
		order: 12,
		phase: "2 · Architecture",
		name: "Architecture decision records",
		why: "Why MySQL, why cookies, why MLS is deferred.",
		have: "in-repo",
		source: "docs/ADR.md"
	},
	{
		order: 13,
		phase: "2 · Architecture",
		name: "Technical specification",
		why: "How it is built on the current stack.",
		have: "in-repo",
		source: "docs/TECH_SPEC.md"
	},
	{
		order: 14,
		phase: "2 · Architecture",
		name: "Data model",
		why: "Tables, FKs, indexes, migrations.",
		have: "in-repo",
		source: "docs/DATA_MODEL.md"
	},
	{
		order: 15,
		phase: "2 · Architecture",
		name: "API contract",
		why: "Normative tRPC + socket events.",
		have: "in-repo",
		source: "docs/API_CONTRACT.md"
	},
	{
		order: 16,
		phase: "2 · Architecture",
		name: "Threat model / SECURITY.md",
		why: "STRIDE + control catalogue.",
		have: "in-repo",
		source: "docs/SECURITY.md"
	},
	{
		order: 17,
		phase: "2 · Architecture",
		name: "Encryption architecture (MLS)",
		why: "Device keys, epochs, archive limits. Track B is the draft.",
		have: "stale",
		source: "docs/ALICE_CHAINS_END_TO_END_PRODUCT_BUILDOUT.md"
	},
	{
		order: 18,
		phase: "2 · Architecture",
		name: "AI participant policy",
		why: "What Alice may read, retain, and say. Legal and product.",
		have: "missing"
	},
	{
		order: 19,
		phase: "2 · Architecture",
		name: "WebRTC media architecture",
		why: "Signaling, TURN, recording policy, SFU vs mesh.",
		have: "missing"
	},
	{
		order: 20,
		phase: "3 · Legal",
		name: "Privacy policy",
		why: "GDPR Art. 13/14. Cannot collect an email without it.",
		have: "missing"
	},
	{
		order: 21,
		phase: "3 · Legal",
		name: "Terms of service",
		why: "Contract with the user and the self-hoster.",
		have: "missing"
	},
	{
		order: 22,
		phase: "3 · Legal",
		name: "Acceptable use policy",
		why: "Abuse, CSAM, spam. Required before public beta.",
		have: "missing"
	},
	{
		order: 23,
		phase: "3 · Legal",
		name: "Data processing agreement",
		why: "Enterprise customers will not sign without a DPA.",
		have: "missing"
	},
	{
		order: 24,
		phase: "3 · Legal",
		name: "Subprocessor register",
		why: "If you ever use a cloud AI or TURN vendor.",
		have: "missing"
	},
	{
		order: 25,
		phase: "3 · Legal",
		name: "Cookie / session notice",
		why: "HMAC cookie is still a cookie.",
		have: "missing"
	},
	{
		order: 26,
		phase: "3 · Legal",
		name: "Vulnerability disclosure policy",
		why: "Where researchers send bugs. Before any public instance.",
		have: "missing"
	},
	{
		order: 27,
		phase: "3 · Legal",
		name: "Open-source license audit / notices",
		why: "MIT + dependency licenses. SBOM later.",
		have: "in-repo",
		source: "LICENSE"
	},
	{
		order: 28,
		phase: "3 · Legal",
		name: "DPIA (GDPR)",
		why: "Messaging + optional AI is high risk. Do this before EU users.",
		have: "missing"
	},
	{
		order: 29,
		phase: "3 · Legal",
		name: "Records of processing (ROPA)",
		why: "Art. 30. Operator document for self-host and hosted.",
		have: "missing"
	},
	{
		order: 30,
		phase: "3 · Legal",
		name: "SOC 2 control mapping",
		why: "Enterprise sales. After the product exists.",
		have: "missing"
	},
	{
		order: 31,
		phase: "4 · Build",
		name: "BUILD_PLAN (task cards)",
		why: "Canonical execution order.",
		have: "in-repo",
		source: "docs/BUILD_PLAN.md"
	},
	{
		order: 32,
		phase: "4 · Build",
		name: "BACKLOG",
		why: "One-line queue. Status more current than CURRENT_STATUS.",
		have: "in-repo",
		source: "BACKLOG.md"
	},
	{
		order: 33,
		phase: "4 · Build",
		name: "TEST_PLAN",
		why: "TC-* catalogue and exit criteria.",
		have: "in-repo",
		source: "docs/TEST_PLAN.md"
	},
	{
		order: 34,
		phase: "4 · Build",
		name: "TRACEABILITY matrix",
		why: "Requirement → task → test. Re-run after Wave 4.",
		have: "stale",
		source: "docs/TRACEABILITY.md"
	},
	{
		order: 35,
		phase: "4 · Build",
		name: "Accessibility audit (WCAG 2.2 AA)",
		why: "S-20 is a baseline, not an audit report.",
		have: "missing"
	},
	{
		order: 36,
		phase: "4 · Build",
		name: "Localization kit",
		why: "Catalogue exists for English announcements only.",
		have: "stale",
		source: "src/i18n/en.ts"
	},
	{
		order: 37,
		phase: "4 · Build",
		name: "CONTRIBUTING.md",
		why: "Human on-ramp. CLAUDE.md is for agents.",
		have: "missing"
	},
	{
		order: 38,
		phase: "5 · Operate",
		name: "Runbooks (10 incidents)",
		why: "Auth outage, backlog, plaintext leak, token compromise.",
		have: "missing"
	},
	{
		order: 39,
		phase: "5 · Operate",
		name: "Incident response plan",
		why: "On-call, 72-hour GDPR clock, user comms.",
		have: "missing"
	},
	{
		order: 40,
		phase: "5 · Operate",
		name: "SLO document",
		why: "PRD has targets. No measured SLOs, no error budget.",
		have: "missing"
	},
	{
		order: 41,
		phase: "5 · Operate",
		name: "Disaster recovery / BCP",
		why: "RPO/RTO by data class. Region failover.",
		have: "missing"
	},
	{
		order: 42,
		phase: "5 · Operate",
		name: "SBOM + release signing process",
		why: "Supply chain. Track B Phase 11.",
		have: "missing"
	},
	{
		order: 43,
		phase: "5 · Operate",
		name: "Pentest statement of work",
		why: "Web, linking, account takeover. Before public beta.",
		have: "missing"
	},
	{
		order: 44,
		phase: "5 · Operate",
		name: "Cryptographic review SOW",
		why: "MLS integration, not a generic AppSec scan.",
		have: "missing"
	},
	{
		order: 45,
		phase: "6 · Ship",
		name: "Public security white paper",
		why: "What you promise. What you do not. Mode comprehension.",
		have: "missing"
	},
	{
		order: 46,
		phase: "6 · Ship",
		name: "App Store / Play listings + privacy nutrition",
		why: "Native is Phase 4. Prepare copy when protocol exists.",
		have: "missing"
	},
	{
		order: 47,
		phase: "6 · Ship",
		name: "Status page policy",
		why: "How you talk when it is down.",
		have: "missing"
	},
	{
		order: 48,
		phase: "6 · Ship",
		name: "Support playbook",
		why: "Device revoke, lost access, abuse reports.",
		have: "missing"
	},
	{
		order: 49,
		phase: "6 · Ship",
		name: "Pricing & packaging",
		why: "Self-host free, hosted seats, TURN costs, Alice spend.",
		have: "missing"
	},
	{
		order: 50,
		phase: "6 · Ship",
		name: "Launch checklist / Gate F",
		why: "No unresolved high findings, 30-day SLO, export/delete proven.",
		have: "in-repo",
		source: "Track B §6 Gate F"
	}
];
var SCORES = [
	{
		area: "Messaging core",
		now: 8,
		enterprise: 9,
		note: "Real, typed, tested. Pagination is the hole."
	},
	{
		area: "Auth & identity",
		now: 5,
		enterprise: 9,
		note: "One OAuth. Need passkeys, OIDC, SCIM."
	},
	{
		area: "Authorization",
		now: 8,
		enterprise: 9,
		note: "Wave 1 closed the leaks. Admin UI missing."
	},
	{
		area: "Realtime scale",
		now: 3,
		enterprise: 8,
		note: "Single process. Redis gated."
	},
	{
		area: "Media / calls",
		now: 1,
		enterprise: 8,
		note: "Buttons. No media plane."
	},
	{
		area: "Encryption",
		now: 2,
		enterprise: 10,
		note: "TLS + HMAC. Server reads everything."
	},
	{
		area: "AI governance",
		now: 0,
		enterprise: 9,
		note: "The differentiator. Not a line of product code."
	},
	{
		area: "Native clients",
		now: 2,
		enterprise: 8,
		note: "Responsive web only."
	},
	{
		area: "Compliance",
		now: 2,
		enterprise: 9,
		note: "Docs about GDPR. No legal, no DPIA, no hold."
	},
	{
		area: "Design / object",
		now: 4,
		enterprise: 10,
		note: "Competent Slack-dark. Not an iPhone."
	},
	{
		area: "Documentation",
		now: 9,
		enterprise: 9,
		note: "Best part of the repo. Partly stale."
	},
	{
		area: "Operability",
		now: 6,
		enterprise: 9,
		note: "Healthz, logs, compose. No runbooks."
	}
];
var FEASIBILITY = {
	verdict: "The current repository can become a daily-usable self-hosted messenger in weeks. It cannot become the iPhone of private rooms without a second architecture. Those are two products that share a name and a feeling — not a codebase.",
	tracks: [{
		name: "Track A — current stack",
		feasible: "High",
		window: "6–12 weeks to product-complete web messenger with calls beta",
		cost: "One focused engineer plus design. TURN infrastructure is the only new vendor.",
		risk: "Chat.tsx gravity. Single IdP. Unmeasured performance. Stale status docs."
	}, {
		name: "Track B — MLS / Alice OS",
		feasible: "Medium, capital-intensive",
		window: "9–18 months to private beta of encrypted multi-device with visible AI",
		cost: "Protocol engineer, two client engineers, applied cryptographer (review), TURN, object storage, AI spend controls.",
		risk: "Rewriting before users. Web-client assurance limits. Archive-vs-forward-secrecy tension. Enterprise legal hold vs PRIVATE mode."
	}],
	go: [
		"Keep Track A alive as the dogfood and the UI shell.",
		"Do not encrypt MySQL plaintext and call it E2EE.",
		"Do not start native apps until the protocol core exists.",
		"Do not sell MANAGED (SSO, hold, DLP) as the first SKU.",
		"Rename to Alisons in one cut when Track A feels finished enough to show."
	],
	noGo: [
		"A 14-month rewrite with no daily users.",
		"Signal Protocol bolted onto the prototype.",
		"Hidden server-side AI over private rooms.",
		"Claiming <100ms P99 or GDPR-ready without evidence."
	]
};
var STORIES = [
	{
		id: "US-01",
		persona: "Founder",
		want: "stand up a private room for my three co-founders this afternoon",
		so: "we stop leaking strategy into Slack",
		status: "partial"
	},
	{
		id: "US-02",
		persona: "Member",
		want: "send a message and know it arrived",
		so: "I do not double-send",
		status: "met"
	},
	{
		id: "US-03",
		persona: "Member",
		want: "see unread counts and presence",
		so: "I know who is here",
		status: "met"
	},
	{
		id: "US-04",
		persona: "Member",
		want: "reply, edit, react, attach",
		so: "the room feels like a modern messenger",
		status: "met"
	},
	{
		id: "US-05",
		persona: "Member",
		want: "search last month",
		so: "I can find the decision",
		status: "partial"
	},
	{
		id: "US-06",
		persona: "Member",
		want: "block a person completely",
		so: "they cannot reach me",
		status: "met"
	},
	{
		id: "US-07",
		persona: "Member",
		want: "call the room",
		so: "we do not jump to another app",
		status: "unmet"
	},
	{
		id: "US-08",
		persona: "Member",
		want: "leave a voice note while walking",
		so: "I am not typing",
		status: "unmet"
	},
	{
		id: "US-09",
		persona: "Member",
		want: "know the host cannot read this",
		so: "I will put real things in it",
		status: "unmet"
	},
	{
		id: "US-10",
		persona: "Member",
		want: "kill a stolen laptop from my phone",
		so: "yesterday's messages stay closed",
		status: "unmet"
	},
	{
		id: "US-11",
		persona: "Member",
		want: "admit Alice to summarize, then remove her",
		so: "AI is a guest with a name",
		status: "unmet"
	},
	{
		id: "US-12",
		persona: "Owner",
		want: "export or erase a member",
		so: "I can answer a DSAR",
		status: "partial"
	},
	{
		id: "US-13",
		persona: "Owner",
		want: "run this on my own metal",
		so: "data never leaves the building",
		status: "partial"
	},
	{
		id: "US-14",
		persona: "IT admin",
		want: "SSO and SCIM",
		so: "offboarding is automatic",
		status: "unmet"
	},
	{
		id: "US-15",
		persona: "Counsel",
		want: "legal hold on a MANAGED room",
		so: "we can answer discovery without breaking PRIVATE rooms",
		status: "unmet"
	},
	{
		id: "US-16",
		persona: "New user",
		want: "be in a room ten minutes after install",
		so: "the product proves itself",
		status: "unmet"
	}
];
var FIXES = [
	{
		id: "H-9",
		title: "Paginate history past 50 messages",
		detail: "The API already takes limit/offset. The client never moves. Jump-to-message lies when the hit is older than the window."
	},
	{
		id: "S-20a",
		title: "Finish the message catalogue",
		detail: "Screen-reader strings moved. Visible Chat and Contacts copy is still inline English."
	},
	{
		id: "S-12b",
		title: "Make validate a required check on main",
		detail: "A red build can still merge. This is a GitHub setting, not a commit."
	},
	{
		id: "S-12a",
		title: "Publish coverage",
		detail: "Needs @vitest/coverage-v8 and a lockfile change. Waiting on an explicit maintainer yes."
	},
	{
		id: "H-7",
		title: "Rename misleading env keys",
		detail: "VITE_KIMI_AUTH_URL is server-only. JWT_SECRET is an HMAC cookie. Names lie."
	},
	{
		id: "STATUS",
		title: "Rewrite CURRENT_STATUS.md",
		detail: "The Aug 12 body still describes a broken clone. Waves 0–4 are done. Newcomers will trust the wrong document."
	},
	{
		id: "GOD",
		title: "Split Chat.tsx",
		detail: "81 KB in one file. Composer, thread, sidebar, group dialog, search, media must become modules before calls or E2EE land in it."
	},
	{
		id: "ADMIN-UI",
		title: "Give S-18 a screen",
		detail: "Owner can list, deactivate, export, erase — only over tRPC. No /admin."
	},
	{
		id: "P-TOOL-10",
		title: "CONTRIBUTING.md",
		detail: "CLAUDE.md is the working agreement. Humans still need a door."
	},
	{
		id: "P-TOOL-6",
		title: "Walk SETUP.md as a stranger",
		detail: "The last unproven operator path. If it fails, the product is not self-hostable."
	}
];
var BLOCKERS = [
	{
		id: "B-IDP",
		title: "Single identity provider",
		detail: "Kimi OAuth is the only door. Enterprise buyers need OIDC/SAML. Consumers need passkeys. Neither exists."
	},
	{
		id: "B-TURN",
		title: "No STUN/TURN estate",
		detail: "Calls cannot ship without a media relay. Coturn or a paid TURN. Not a weekend stub."
	},
	{
		id: "B-CRYPTO",
		title: "E2EE is a re-architecture",
		detail: "Bolting Signal onto MySQL plaintext is throwaway. MLS needs a Rust core, device keys, and an event log. Track B is parked for this reason."
	},
	{
		id: "B-SCALE",
		title: "Presence is in-process",
		detail: "Two Node instances split the truth. Redis adapter is gated, not built."
	},
	{
		id: "B-LEGAL",
		title: "Zero product legal",
		detail: "MIT code license is not a privacy policy, DPA, or VDP. You cannot ship to the EU or an enterprise without them."
	},
	{
		id: "B-NAME",
		title: "Alisons is not registered here",
		detail: "The repo, cookies, sessions, and docs still say Alice Chains. Trademark, domains, and cookie names must move together."
	},
	{
		id: "B-STORE",
		title: "Object storage for production attachments",
		detail: "Filesystem driver is fine locally. Production needs S3/R2 credentials and a CORS bucket."
	},
	{
		id: "B-MEASURE",
		title: "No performance numbers",
		detail: "PRD targets <100ms P99 delivery. Current state: unmeasured. You cannot claim what you have not timed."
	}
];
var OPPORTUNITIES = [
	{
		id: "O-OBJECT",
		title: "One object, not a Slack clone",
		detail: "The iPhone of rooms. Four pages today. The winning product is a single surface: room, people, call, memory, a visible AI — not a left-nav of apps."
	},
	{
		id: "O-PRIVATE",
		title: "Privacy as the brand",
		detail: "Mattermost looks like 2014. Signal has no teams. Slack cannot self-host. The empty cell is beautiful and private."
	},
	{
		id: "O-ALICE",
		title: "Alice as a guest, never a spy",
		detail: "Admit an AI into a room the way you admit a person. Disclose retention. Remove her like a member. That is the company."
	},
	{
		id: "O-SELFHOST",
		title: "docker compose up as the sales motion",
		detail: "If a founder can run Alisons in five minutes, you beat Mattermost on feeling and Slack on sovereignty."
	},
	{
		id: "O-RENAME",
		title: "Alisons is a better name than Alice Chains",
		detail: "Chains sounds like crypto theatre. Alisons sounds like a person. Keep Alice as the AI guest. Rename the product."
	},
	{
		id: "O-WEB-FIRST",
		title: "Ship the web object before native",
		detail: "PWA + excellent desktop web beats a thin React Native wrap. Native after the protocol core exists."
	}
];
var STRATEGIES = [
	{
		id: "S1",
		title: "Stabilize the prototype. Do not rewrite it yet.",
		detail: "Waves 0–4 are done. Finish hygiene. Daily-drive it with ten people. The current stack is the learning vehicle."
	},
	{
		id: "S2",
		title: "Split the god component before adding gravity.",
		detail: "Calls, E2EE, and Alice cannot land in an 81k file. Extract thread, composer, sidebar, inspectors."
	},
	{
		id: "S3",
		title: "Build the iPhone chrome on this stack, protocol later.",
		detail: "Future-state UI (this model) can ship as the product shell while Track B replaces the wire. Do not wait for MLS to make it feel finished."
	},
	{
		id: "S4",
		title: "When E2EE starts, start MLS — not Signal-on-MySQL.",
		detail: "The parked program is the honest one. Gate B is cryptographic proof with two clients, not a library import."
	},
	{
		id: "S5",
		title: "Enterprise is a mode, not the first user.",
		detail: "First market: trusted groups. MANAGED mode (legal hold, SSO) comes after PRIVATE works. Do not let procurement write the MVP."
	},
	{
		id: "S6",
		title: "Rename in one cut.",
		detail: "Alisons everywhere: cookie, session, docs, package, mark. Half-renames rot trust."
	}
];
var BUILDS = [
	{
		id: "R1",
		title: "Next 14 days",
		detail: "H-9 pagination. Split Chat.tsx. Admin page. CURRENT_STATUS rewrite. Brand pass to Alisons. Walk SETUP.md as a stranger."
	},
	{
		id: "R2",
		title: "Next 60 days — M5 calls beta",
		detail: "WebRTC signaling over existing sockets. Coturn in compose. Call overlay. Voice notes. Do not start E2EE in this window."
	},
	{
		id: "R3",
		title: "Next 90 days — product complete on current stack",
		detail: "Onboarding. Invite links. Delete-account. Member export. Notification center. Public legal drafts. Ten-person dogfood."
	},
	{
		id: "R4",
		title: "Then — open Track B",
		detail: "Rust protocol core, MLS vectors, device linking. Only after real usage. Otherwise you will encrypt a product nobody opens."
	}
];
function Spec() {
	const { section } = Route.useParams();
	const id = section;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-8 px-4 py-8 md:flex-row md:py-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: "md:w-44 md:shrink-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-xs tracking-[0.18em] text-subtle",
				children: "SPEC"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex gap-1 overflow-x-auto md:flex-col md:overflow-visible",
				children: SECTIONS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/spec/$section",
					params: { section: s.id },
					className: cn("block whitespace-nowrap rounded-full px-3 py-1.5 text-sm", s.id === id ? "bg-primary text-primary-foreground" : "text-muted hover:text-foreground"),
					children: s.label
				}) }, s.id))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "min-w-0 flex-1 pb-16",
			children: [
				id === "features" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Features, {}) : null,
				id === "pages" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pages, {}) : null,
				id === "build" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Build, {}) : null,
				id === "feasibility" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feasibility, {}) : null,
				id === "documents" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Docs, {}) : null,
				id === "stories" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stories, {}) : null,
				id === "roadmap" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Roadmap, {}) : null
			]
		})]
	}) });
}
function Features() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl tracking-tight",
			children: "Features"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-2xl text-sm leading-relaxed text-muted",
			children: "The complete capability list for Alisons, scored against the Alice Chains repository — not the brochure."
		}),
		[
			"shipped",
			"stub",
			"hygiene",
			"specified",
			"parked",
			"missing"
		].map((g) => {
			const rows = FEATURES.filter((f) => f.status === g);
			if (!rows.length) return null;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "text-xs font-medium tracking-[0.18em] text-subtle",
					children: [
						STATUS_LABEL[g].toUpperCase(),
						" · ",
						rows.length
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 divide-y divide-border",
					children: rows.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-baseline justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: f.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-[11px] text-subtle",
									children: f.id
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: f.story
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-subtle",
								children: f.note
							})
						]
					}, f.id))
				})]
			}, g);
		})
	] });
}
function Pages() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl tracking-tight",
			children: "Pages, subpages, popups"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-2xl text-sm leading-relaxed text-muted",
			children: "Every surface that exists, is stubbed, or is owed. Today the running app has four routes. The future-state room adds the rest as overlays of one object."
		}),
		[
			"page",
			"subpage",
			"tab",
			"drawer",
			"dialog",
			"menu",
			"overlay",
			"banner",
			"tool"
		].map((k) => {
			const rows = SURFACES.filter((s) => s.kind === k);
			if (!rows.length) return null;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs font-medium tracking-[0.18em] text-subtle",
					children: k.toUpperCase()
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[36rem] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-xs text-subtle",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "pb-2 font-medium",
									children: "Name"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "pb-2 font-medium",
									children: "Path"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "pb-2 font-medium",
									children: "Status"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-border",
							children: rows.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "py-3 pr-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium",
										children: s.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: s.purpose
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 pr-4 font-mono text-xs text-subtle",
									children: s.path
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { status: s.status })
								})
							] }, s.path))
						})]
					})
				})]
			}, k);
		})
	] });
}
function Build() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl tracking-tight",
			children: "Technical build-out"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-2xl text-sm leading-relaxed text-muted",
			children: "How each window is built today, and what it must become. Citations are to the Alice Chains tree, not this preview."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-8 space-y-4",
			children: SURFACES.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-3xl bg-card p-5 shadow-[0_0_0_1px_rgba(255,255,255,0.06)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs tabular-nums text-subtle",
								children: String(i + 1).padStart(2, "0")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-base font-medium",
								children: s.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { status: s.status })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-mono text-xs text-subtle",
						children: [s.path, s.parent ? ` · parent ${s.parent}` : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: s.purpose
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-foreground",
						children: s.build
					})
				]
			}, s.path))
		})
	] });
}
function Feasibility() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl tracking-tight",
			children: "Feasibility"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-5 max-w-2xl text-[17px] leading-relaxed text-muted",
			children: FEASIBILITY.verdict
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-10 space-y-3",
			children: SCORES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-1 flex justify-between text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s.area }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums text-muted",
						children: [
							"now ",
							s.now,
							"/10 · enterprise ",
							s.enterprise,
							"/10"
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1.5 overflow-hidden rounded-full bg-raised",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-accent",
						style: { width: `${s.now * 10}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-subtle",
					children: s.note
				})
			] }, s.area))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-12 grid gap-4 md:grid-cols-2",
			children: FEASIBILITY.tracks.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-3xl bg-card p-5 shadow-[0_0_0_1px_rgba(255,255,255,0.06)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.16em] text-subtle",
						children: t.feasible.toUpperCase()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-2xl tracking-tight",
						children: t.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: t.window
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: t.cost
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-subtle",
						children: t.risk
					})
				]
			}, t.name))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-12 font-display text-2xl tracking-tight",
			children: "Go"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 list-disc space-y-2 pl-5 text-sm text-muted",
			children: FEASIBILITY.go.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: g }, g))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-10 font-display text-2xl tracking-tight",
			children: "No"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 list-disc space-y-2 pl-5 text-sm text-muted",
			children: FEASIBILITY.noGo.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: g }, g))
		})
	] });
}
function Docs() {
	const phases = [...new Set(DOCUMENTS.map((d) => d.phase))];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl tracking-tight",
			children: "Documents to procure"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-2xl text-sm leading-relaxed text-muted",
			children: "Chronological. Engineering artefacts already in the repo are marked. Legal, brand, and operations are mostly absent. Enterprise future-state does not begin at a Dockerfile."
		}),
		phases.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xs font-medium tracking-[0.18em] text-subtle",
				children: p.toUpperCase()
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-4 space-y-3",
				children: DOCUMENTS.filter((d) => d.phase === p).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-8 shrink-0 font-mono text-xs tabular-nums text-subtle",
						children: String(d.order).padStart(2, "0")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-medium",
							children: [
								d.name,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("text-xs font-normal", d.have === "in-repo" ? "text-ok" : d.have === "stale" ? "text-warn" : "text-bad"),
									children: d.have === "in-repo" ? "in repo" : d.have === "stale" ? "stale" : "procure"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: d.why
						}),
						d.source ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-[11px] text-subtle",
							children: d.source
						}) : null
					] })]
				}, d.order))
			})]
		}, p))
	] });
}
function Stories() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl tracking-tight",
			children: "User stories"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-2xl text-sm leading-relaxed text-muted",
			children: "As a person, I want a room I would actually use. Status is against the running repository."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-8 divide-y divide-border",
			children: STORIES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-subtle",
						children: s.id
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("text-xs", s.status === "met" ? "text-ok" : s.status === "partial" ? "text-warn" : "text-bad"),
						children: s.status
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm",
					children: [
						"As a ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-accent",
							children: s.persona
						}),
						", I want to ",
						s.want,
						" so that ",
						s.so,
						"."
					]
				})]
			}, s.id))
		})
	] });
}
function Roadmap() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl tracking-tight",
			children: "Fixes, blockers, strategy"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-2xl text-sm leading-relaxed text-muted",
			children: "Nonstop inventory. Work top to bottom. Do not start Track B to avoid finishing Track A."
		}),
		[
			{
				title: "Fixes",
				items: FIXES
			},
			{
				title: "Blockers",
				items: BLOCKERS
			},
			{
				title: "Opportunities",
				items: OPPORTUNITIES
			},
			{
				title: "Strategies",
				items: STRATEGIES
			},
			{
				title: "Build recommendations",
				items: BUILDS
			}
		].map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl tracking-tight",
				children: b.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 space-y-4",
				children: b.items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-medium",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-subtle",
							children: it.id
						}),
						" ",
						it.title
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: it.detail
				})] }, it.id))
			})]
		}, b.title))
	] });
}
//#endregion
export { Spec as component };
