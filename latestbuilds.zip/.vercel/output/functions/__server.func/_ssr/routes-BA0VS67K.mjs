import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Shield, c as Phone, d as Image, f as FileText, l as Paperclip, n as Video, o as Settings, p as ArrowLeft, r as Users, s as Search, t as X, u as Mic } from "../_libs/lucide-react.mjs";
import { n as cn, t as Mark } from "./mark-BSEiXSy5.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BA0VS67K.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PEOPLE = [
	{
		id: "me",
		name: "You",
		handle: "you",
		initials: "YO",
		status: "In the room",
		online: true
	},
	{
		id: "nara",
		name: "Nara Okonkwo",
		handle: "nara",
		initials: "NO",
		status: "In the studio",
		online: true
	},
	{
		id: "lev",
		name: "Lev Hartmann",
		handle: "lev",
		initials: "LH",
		status: "On a train",
		online: true
	},
	{
		id: "mira",
		name: "Mira Chen",
		handle: "mira",
		initials: "MC",
		status: "Deep work",
		online: false
	},
	{
		id: "alice",
		name: "Alice",
		handle: "alice",
		initials: "AL",
		status: "In Studio",
		online: true
	}
];
var ROOMS = [
	{
		id: "studio",
		name: "Studio",
		kind: "group",
		preview: "Nara: the object has to fit in one hand",
		time: "2m",
		unread: 2,
		encrypted: true,
		alice: true,
		members: [
			"me",
			"nara",
			"lev",
			"mira",
			"alice"
		]
	},
	{
		id: "nara",
		name: "Nara Okonkwo",
		kind: "dm",
		preview: "Ship the feeling before the protocol",
		time: "11m",
		unread: 0,
		encrypted: true,
		members: ["me", "nara"]
	},
	{
		id: "ops",
		name: "Ops",
		kind: "group",
		preview: "You: pagination is the honest bug",
		time: "1h",
		unread: 0,
		encrypted: false,
		members: [
			"me",
			"lev",
			"mira"
		]
	},
	{
		id: "mira",
		name: "Mira Chen",
		kind: "dm",
		preview: "Hold cannot touch PRIVATE rooms",
		time: "Yesterday",
		unread: 0,
		encrypted: true,
		members: ["me", "mira"]
	}
];
var MESSAGES = [
	{
		id: "s1",
		convId: "studio",
		authorId: "system",
		text: "Studio · private · Alice joined",
		at: "09:12",
		kind: "system"
	},
	{
		id: "s2",
		convId: "studio",
		authorId: "nara",
		text: "This has to be a room you would put your life in. Not a left-nav of apps.",
		at: "09:14"
	},
	{
		id: "s3",
		convId: "studio",
		authorId: "lev",
		text: "Direct, groups, presence, search, files. Calls next.",
		at: "09:16",
		reactions: [{
			glyph: "→",
			n: 2,
			mine: true
		}]
	},
	{
		id: "s4",
		convId: "studio",
		authorId: "me",
		text: "Keep the wire. Change the object.",
		at: "09:17",
		mine: true
	},
	{
		id: "s5",
		convId: "studio",
		authorId: "alice",
		text: "I can see this room from join. I cannot see Nara's DMs. Remove me and I lose the thread.",
		at: "09:18"
	},
	{
		id: "s6",
		convId: "studio",
		authorId: "mira",
		text: "If counsel needs hold, that is a different mode.",
		at: "09:21",
		replyTo: "s5"
	},
	{
		id: "s7",
		convId: "studio",
		authorId: "nara",
		text: "The object has to fit in one hand.",
		at: "09:24"
	},
	{
		id: "n1",
		convId: "nara",
		authorId: "nara",
		text: "Ship the feeling. People do not fall in love with the protocol.",
		at: "08:40"
	},
	{
		id: "n2",
		convId: "nara",
		authorId: "me",
		text: "Then this surface is the argument.",
		at: "08:41",
		mine: true,
		edited: true
	},
	{
		id: "o1",
		convId: "ops",
		authorId: "lev",
		text: "History has to page. Fifty messages is not a product.",
		at: "Yesterday"
	},
	{
		id: "o2",
		convId: "ops",
		authorId: "me",
		text: "Pagination is the honest bug.",
		at: "Yesterday",
		mine: true
	},
	{
		id: "m1",
		convId: "mira",
		authorId: "mira",
		text: "Legal hold cannot touch PRIVATE rooms.",
		at: "Yesterday"
	}
];
function person(id) {
	return PEOPLE.find((p) => p.id === id);
}
var KEY = "alisons-v1";
function load() {
	if (typeof window === "undefined") return null;
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return null;
		return JSON.parse(raw);
	} catch {
		return null;
	}
}
function save(s) {
	if (typeof window === "undefined") return;
	localStorage.setItem(KEY, JSON.stringify(s));
}
function bumpRoom(rooms, roomId, preview) {
	return rooms.map((r) => r.id === roomId ? {
		...r,
		preview,
		time: "Now",
		unread: 0
	} : r);
}
var useMessenger = create((set, get) => ({
	roomId: "studio",
	rooms: ROOMS,
	messages: MESSAGES,
	draft: "",
	overlay: null,
	query: "",
	mobile: "list",
	typing: null,
	muted: false,
	calling: false,
	hydrate: () => {
		const data = load();
		if (!data) return;
		set({
			roomId: data.roomId,
			rooms: data.rooms,
			messages: data.messages
		});
	},
	setRoom: (id) => {
		set((s) => ({
			roomId: id,
			mobile: "thread",
			overlay: null,
			rooms: s.rooms.map((r) => r.id === id ? {
				...r,
				unread: 0
			} : r)
		}));
		persist();
	},
	setDraft: (draft) => set({ draft }),
	setReply: (replyTo) => set({ replyTo }),
	setOverlay: (overlay) => set({ overlay }),
	setQuery: (query) => set({ query }),
	setMobile: (mobile) => set({ mobile }),
	toggleMute: () => set((s) => ({ muted: !s.muted })),
	startCall: () => set({
		overlay: "call",
		calling: true
	}),
	endCall: () => set({
		overlay: null,
		calling: false,
		muted: false
	}),
	openDm: (personId, name) => {
		if (get().rooms.find((r) => r.id === personId)) {
			get().setRoom(personId);
			return;
		}
		const room = {
			id: personId,
			name,
			kind: "dm",
			preview: "New conversation",
			time: "Now",
			unread: 0,
			encrypted: true,
			members: ["me", personId]
		};
		set((s) => ({
			rooms: [room, ...s.rooms],
			roomId: personId,
			mobile: "thread",
			overlay: null
		}));
		persist();
	},
	send: (override, kind = "text") => {
		const { draft, roomId, replyTo, messages, rooms } = get();
		const text = (override ?? draft).trim();
		if (!text) return;
		const msg = {
			id: `m${Date.now()}`,
			convId: roomId,
			authorId: "me",
			text,
			at: nowClock(),
			mine: true,
			replyTo,
			kind
		};
		set({
			messages: [...messages, msg],
			draft: "",
			replyTo: void 0,
			rooms: bumpRoom(rooms, roomId, `You: ${text}`)
		});
		persist();
		scheduleReply(roomId);
	},
	react: (id) => {
		set({ messages: get().messages.map((m) => {
			if (m.id !== id) return m;
			const current = m.reactions ?? [];
			if (current.find((r) => r.mine)) return {
				...m,
				reactions: current.map((r) => r.mine ? {
					...r,
					n: r.n - 1,
					mine: false
				} : r).filter((r) => r.n > 0)
			};
			return {
				...m,
				reactions: [...current, {
					glyph: "→",
					n: 1,
					mine: true
				}]
			};
		}) });
		persist();
	}
}));
function persist() {
	const s = useMessenger.getState();
	save({
		roomId: s.roomId,
		messages: s.messages,
		rooms: s.rooms
	});
}
function nowClock() {
	return (/* @__PURE__ */ new Date()).toLocaleTimeString([], {
		hour: "2-digit",
		minute: "2-digit"
	});
}
var REPLIES = [
	"Heard.",
	"Keep going.",
	"That lands.",
	"Yes. One room.",
	"Ship it while it's warm.",
	"I'm in."
];
function scheduleReply(roomId) {
	const room = useMessenger.getState().rooms.find((r) => r.id === roomId);
	const other = room?.members.find((id) => id !== "me" && id !== "alice") ?? room?.members.find((id) => id !== "me");
	if (!other) return;
	window.setTimeout(() => {
		if (useMessenger.getState().roomId === roomId) useMessenger.setState({ typing: other });
	}, 500);
	window.setTimeout(() => {
		const s = useMessenger.getState();
		const text = REPLIES[Math.floor(Math.random() * REPLIES.length)];
		const msg = {
			id: `r${Date.now()}`,
			convId: roomId,
			authorId: other,
			text,
			at: nowClock()
		};
		useMessenger.setState({
			typing: null,
			messages: [...s.messages, msg],
			rooms: s.rooms.map((r) => r.id === roomId ? {
				...r,
				preview: text,
				time: "Now",
				unread: s.roomId === roomId ? 0 : r.unread + 1
			} : r)
		});
		persist();
	}, 1400);
}
function Messenger() {
	const roomId = useMessenger((s) => s.roomId);
	const rooms = useMessenger((s) => s.rooms);
	const mobile = useMessenger((s) => s.mobile);
	const overlay = useMessenger((s) => s.overlay);
	const hydrate = useMessenger((s) => s.hydrate);
	const room = rooms.find((r) => r.id === roomId) ?? rooms[0];
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-dvh min-h-0 bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: cn("w-full shrink-0 flex-col border-r border-border bg-card md:flex md:w-80", mobile === "list" ? "flex" : "hidden md:flex"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cn("min-w-0 flex-1 flex-col", mobile === "thread" ? "flex" : "hidden md:flex"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThreadHeader, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thread, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inspector, { className: "hidden lg:flex" }),
			overlay ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverlayPane, {
				overlay,
				roomName: room.name
			}) : null
		]
	});
}
function Inbox() {
	const roomId = useMessenger((s) => s.roomId);
	const rooms = useMessenger((s) => s.rooms);
	const setRoom = useMessenger((s) => s.setRoom);
	const setOverlay = useMessenger((s) => s.setOverlay);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between px-4 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl tracking-tight",
				children: "Alisons"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "New conversation",
				onClick: () => setOverlay("contacts"),
				className: "grid size-11 place-items-center rounded-full text-muted hover:bg-raised hover:text-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Open settings",
				onClick: () => setOverlay("settings"),
				className: "grid size-11 place-items-center rounded-full text-muted hover:bg-raised hover:text-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" })
			})]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "min-h-0 flex-1 overflow-y-auto px-2 pb-4",
		children: rooms.map((r) => {
			const active = r.id === roomId;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setRoom(r.id),
				className: cn("flex w-full items-start gap-3 rounded-2xl px-3 py-3 text-left", active ? "bg-raised" : "hover:bg-raised/60"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						initials: r.name.slice(0, 2).toUpperCase(),
						alice: r.alice
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-baseline justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-sm font-medium",
								children: r.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 text-xs tabular-nums text-subtle",
								children: r.time
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 block truncate text-xs text-muted",
							children: r.preview
						})]
					}),
					r.unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 grid size-5 place-items-center rounded-full bg-primary text-xs font-medium text-primary-foreground tabular-nums",
						children: r.unread
					}) : null
				]
			}) }, r.id);
		})
	})] });
}
function ThreadHeader() {
	const rooms = useMessenger((s) => s.rooms);
	const roomId = useMessenger((s) => s.roomId);
	const setMobile = useMessenger((s) => s.setMobile);
	const setOverlay = useMessenger((s) => s.setOverlay);
	const startCall = useMessenger((s) => s.startCall);
	const room = rooms.find((r) => r.id === roomId) ?? rooms[0];
	const online = room.members.some((id) => person(id)?.online && id !== "me");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex items-center gap-2 border-b border-border px-3 py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "grid size-11 place-items-center rounded-full text-muted hover:text-foreground md:hidden",
				"aria-label": "Back to rooms",
				onClick: () => setMobile("list"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
				initials: room.name.slice(0, 2).toUpperCase(),
				alice: room.alice
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-sm font-medium",
					children: room.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "truncate text-xs text-muted",
					children: [online ? "Active now" : "Away", room.alice ? " · Alice in the room" : ""]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
				label: "Search this room",
				onClick: () => setOverlay("search"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
				label: "Files and photos",
				onClick: () => setOverlay("media"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
				label: "Start a voice call",
				onClick: startCall,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
				label: "People",
				onClick: () => setOverlay("people"),
				className: "lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" })
			})
		]
	});
}
function Thread() {
	const roomId = useMessenger((s) => s.roomId);
	const messages = useMessenger((s) => s.messages);
	const typing = useMessenger((s) => s.typing);
	const react = useMessenger((s) => s.react);
	const setReply = useMessenger((s) => s.setReply);
	const thread = messages.filter((m) => m.convId === roomId);
	const end = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		end.current?.scrollIntoView({ block: "end" });
	}, [
		thread.length,
		roomId,
		typing
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-0 flex-1 overflow-y-auto px-4 py-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-2xl flex-col gap-4",
			children: [
				thread.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bubble, {
					msg: m,
					all: thread,
					onReact: () => react(m.id),
					onReply: () => setReply(m.id)
				}, m.id)),
				typing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "px-1 text-xs text-muted",
					children: [person(typing)?.name ?? "Someone", " is writing…"]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: end })
			]
		})
	});
}
function Bubble({ msg, all, onReact, onReply }) {
	if (msg.kind === "system") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "self-center text-center text-xs text-subtle",
		children: msg.text
	});
	const who = person(msg.authorId);
	const quoted = msg.replyTo ? all.find((x) => x.id === msg.replyTo) : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("flex max-w-[85%] flex-col gap-1", msg.mine ? "self-end items-end" : "self-start"),
		children: [
			!msg.mine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 text-xs font-medium text-muted",
				children: who?.name ?? "Unknown"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed", msg.mine ? "rounded-br-sm bg-primary text-primary-foreground" : "rounded-bl-sm bg-raised text-foreground shadow-border"),
				children: [
					quoted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("mb-1.5 border-l-2 pl-2 text-xs", msg.mine ? "border-primary-foreground/40 text-primary-foreground/70" : "border-accent text-muted"),
						children: quoted.text
					}) : null,
					msg.kind === "file" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4" }), msg.text]
					}) : msg.kind === "voice" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" }), msg.text]
					}) : msg.text,
					msg.edited ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 text-xs opacity-60",
						children: "edited"
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 px-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
						className: "text-xs tabular-nums text-subtle",
						children: msg.at
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onReply,
						className: "text-xs text-subtle hover:text-foreground",
						children: "Reply"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onReact,
						className: "text-xs text-subtle hover:text-foreground",
						children: "Mark"
					}),
					msg.reactions?.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded-full bg-raised px-1.5 text-xs text-muted",
						children: [
							r.glyph,
							" ",
							r.n
						]
					}, r.glyph))
				]
			})
		]
	});
}
function Composer() {
	const draft = useMessenger((s) => s.draft);
	const setDraft = useMessenger((s) => s.setDraft);
	const send = useMessenger((s) => s.send);
	const replyTo = useMessenger((s) => s.replyTo);
	const setReply = useMessenger((s) => s.setReply);
	const quoted = useMessenger((s) => s.messages).find((m) => m.id === replyTo);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-t border-border px-4 py-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-2xl",
			children: [quoted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between rounded-xl bg-raised px-3 py-2 text-xs text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "truncate",
					children: ["Replying · ", quoted.text]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Cancel reply",
					onClick: () => setReply(void 0),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
				})]
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end gap-1 rounded-3xl bg-raised p-1.5 shadow-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Attach a file",
						onClick: () => send("brief.pdf", "file"),
						className: "grid size-11 place-items-center text-muted hover:text-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Send a voice note",
						onClick: () => send("Voice note · 0:04", "voice"),
						className: "grid size-11 place-items-center text-muted hover:text-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 1,
						value: draft,
						"aria-label": "Message",
						onChange: (e) => setDraft(e.target.value),
						onKeyDown: (e) => {
							if (e.key === "Enter" && !e.shiftKey) {
								e.preventDefault();
								send();
							}
						},
						placeholder: "Message",
						className: "max-h-32 min-h-11 flex-1 resize-none bg-transparent py-2.5 text-sm text-foreground outline-none placeholder:text-subtle"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => send(),
						disabled: !draft.trim(),
						className: "rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground disabled:opacity-40",
						children: "Send"
					})
				]
			})]
		})
	});
}
function Inspector({ className }) {
	const rooms = useMessenger((s) => s.rooms);
	const roomId = useMessenger((s) => s.roomId);
	const setOverlay = useMessenger((s) => s.setOverlay);
	const startCall = useMessenger((s) => s.startCall);
	const room = rooms.find((r) => r.id === roomId) ?? rooms[0];
	const members = room.members.map((id) => person(id)).filter(Boolean);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: cn("w-72 shrink-0 flex-col border-l border-border bg-card", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-5 py-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-subtle",
						children: "ROOM"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-2xl tracking-tight",
						children: room.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [
							room.kind === "group" ? "Group" : "Direct",
							" · ",
							members.length,
							" people"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-4 rounded-2xl bg-raised p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-4 text-accent" }), room.encrypted ? "Private" : "Shared host"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs leading-relaxed text-muted",
						children: room.encrypted ? "Only people in this room. Devices stay yours." : "Ops is on the current stack. Treat it as dogfood."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: startCall,
						className: "mt-3 w-full rounded-full bg-primary py-2 text-sm font-medium text-primary-foreground",
						children: "Call"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 px-1 text-xs font-medium tracking-widest text-subtle",
						children: "PEOPLE"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-1",
						children: members.map((p) => p ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 rounded-xl px-2 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
									initials: p.initials,
									alice: p.id === "alice"
								}), p.online ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute bottom-0 right-0 size-2 rounded-full bg-ok" }) : null]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-sm",
									children: p.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-xs text-muted",
									children: p.status
								})]
							})]
						}, p.id) : null)
					}),
					room.alice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOverlay("alice"),
						className: "mt-4 w-full rounded-2xl border border-border px-3 py-3 text-left text-xs text-muted hover:text-foreground",
						children: "Alice is a guest. Open her terms."
					}) : null
				]
			})
		]
	});
}
function OverlayPane({ overlay, roomName }) {
	const setOverlay = useMessenger((s) => s.setOverlay);
	const query = useMessenger((s) => s.query);
	const setQuery = useMessenger((s) => s.setQuery);
	const messages = useMessenger((s) => s.messages);
	const roomId = useMessenger((s) => s.roomId);
	const rooms = useMessenger((s) => s.rooms);
	const openDm = useMessenger((s) => s.openDm);
	const muted = useMessenger((s) => s.muted);
	const toggleMute = useMessenger((s) => s.toggleMute);
	const endCall = useMessenger((s) => s.endCall);
	const calling = useMessenger((s) => s.calling);
	const [elapsed, setElapsed] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!calling) {
			setElapsed(0);
			return;
		}
		const t = window.setInterval(() => setElapsed((n) => n + 1), 1e3);
		return () => window.clearInterval(t);
	}, [calling]);
	const hits = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		if (q.length < 2) return [];
		return messages.filter((m) => m.convId === roomId && m.text.toLowerCase().includes(q));
	}, [
		messages,
		query,
		roomId
	]);
	const media = messages.filter((m) => m.convId === roomId && (m.kind === "file" || m.kind === "image" || m.kind === "voice"));
	const title = {
		search: "Search",
		contacts: "People",
		settings: "Settings",
		call: roomName,
		media: "Files",
		alice: "Alice",
		people: "Room",
		compose: "New"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-30 flex items-end justify-center bg-background/70 p-3 md:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-label": title[overlay],
			className: "flex max-h-[88dvh] w-full max-w-lg flex-col rounded-3xl bg-card p-5 shadow-border",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl tracking-tight",
						children: title[overlay]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Close",
						onClick: () => overlay === "call" ? endCall() : setOverlay(null),
						className: "grid size-11 place-items-center rounded-full text-muted hover:text-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}),
				overlay === "search" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-0 flex-1 flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						autoFocus: true,
						value: query,
						onChange: (e) => setQuery(e.target.value),
						placeholder: `Search ${roomName}`,
						className: "h-11 rounded-2xl bg-raised px-4 text-sm outline-none ring-1 ring-border focus:ring-accent"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "min-h-0 flex-1 overflow-y-auto",
						children: [hits.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "border-b border-border py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: person(h.authorId)?.name
							}), h.text]
						}, h.id)), query.trim().length >= 2 && hits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "py-8 text-center text-sm text-muted",
							children: "Nothing in this room."
						}) : null]
					})]
				}) : null,
				overlay === "contacts" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "overflow-y-auto",
					children: PEOPLE.filter((p) => p.id !== "me").map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
								initials: p.initials,
								alice: p.id === "alice"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm",
									children: p.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: p.status
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => openDm(p.id, p.name),
								className: "rounded-full bg-raised px-3 py-2 text-xs font-medium hover:bg-primary hover:text-primary-foreground",
								children: "Message"
							})
						]
					}, p.id))
				}) : null,
				overlay === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Display name",
							value: "You"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Status",
							value: "In the room"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/spec/$section",
							params: { section: "features" },
							className: "block pt-2 text-xs text-muted underline-offset-4 hover:text-foreground hover:underline",
							children: "Internal spec"
						})
					]
				}) : null,
				overlay === "call" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center gap-6 py-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-24 place-items-center rounded-full bg-raised",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-10 text-muted" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl",
								children: roomName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm tabular-nums text-muted",
								children: [
									String(Math.floor(elapsed / 60)).padStart(2, "0"),
									":",
									String(elapsed % 60).padStart(2, "0")
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": muted ? "Unmute" : "Mute",
									onClick: toggleMute,
									className: cn("grid size-12 place-items-center rounded-full", muted ? "bg-primary text-primary-foreground" : "bg-raised text-muted"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-12 place-items-center rounded-full bg-raised text-muted",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: endCall,
									className: "grid size-12 place-items-center rounded-full bg-bad text-foreground",
									"aria-label": "End call",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4 rotate-[135deg]" })
								})
							]
						})
					]
				}) : null,
				overlay === "media" ? media.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-10 text-center text-sm text-muted",
					children: "Nothing shared yet. Attach a file from the composer."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "overflow-y-auto",
					children: media.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 border-b border-border py-3 text-sm",
						children: [m.kind === "voice" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4 text-muted" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4 text-muted" }), m.text]
					}, m.id))
				}) : null,
				overlay === "alice" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 text-sm leading-relaxed text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-foreground",
							children: "Alice is a visible participant. She is never a backend observer."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Access begins after admission. History before join is closed unless you share it." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Removal is ordinary membership removal." })
					]
				}) : null,
				overlay === "people" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inspector, { className: "flex border-0 bg-transparent" }) : null,
				overlay === "compose" ? null : null,
				rooms.length === 0 ? null : null
			]
		})
	});
}
function Field({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			defaultValue: value,
			className: "mt-1 h-11 w-full rounded-2xl bg-raised px-4 text-sm outline-none ring-1 ring-border"
		})]
	});
}
function Avatar({ initials, alice }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid size-10 shrink-0 place-items-center rounded-full text-xs font-medium", alice ? "bg-accent/20 text-accent" : "bg-raised text-foreground"),
		children: alice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-4" }) : initials
	});
}
function IconBtn({ label, onClick, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		className: cn("grid size-11 place-items-center rounded-full text-muted hover:bg-raised hover:text-foreground", className),
		children
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Messenger, {});
}
//#endregion
export { Home as component };
