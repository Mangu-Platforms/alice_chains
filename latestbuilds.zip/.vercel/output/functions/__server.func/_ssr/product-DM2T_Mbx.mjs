//#region node_modules/.nitro/vite/services/ssr/assets/product-DM2T_Mbx.js
var SplitComponent = () => null;
//#endregion
export { SplitComponent as component };
